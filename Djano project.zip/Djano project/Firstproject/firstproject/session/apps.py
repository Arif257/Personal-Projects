from django.apps import AppConfig


class SessionConfig(AppConfig):
    name = 'session'
