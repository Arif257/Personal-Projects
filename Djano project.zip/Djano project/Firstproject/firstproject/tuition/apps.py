from django.apps import AppConfig


class TuitionConfig(AppConfig):
    name = 'tuition'
