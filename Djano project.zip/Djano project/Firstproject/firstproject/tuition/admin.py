from django.contrib import admin
from.models import Contact,Post,Subject,Class_in

# Register your models here.
admin.site.register(Contact)
admin.site.register(Post)
admin.site.register(Subject)
admin.site.register(Class_in)