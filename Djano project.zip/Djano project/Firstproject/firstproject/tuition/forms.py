from django import forms
from.models import Contact,Post

class ContactForm(forms.ModelForm):
    class Meta:
        model=Contact
        fields='__all__'
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control', 'placeholder':'Enter your name: '}),
            'phone':forms.TextInput(attrs={'class':'form-control', 'placeholder':'Enter your phone: '}),
            'content':forms.Textarea(attrs={'class':'form-control', 'placeholder':'Write Something here: ','rows':4}),
        }

        labels={
            'name': 'Your Name',
            'phone': 'Your Phone',
            'content': 'Content'
        }
    # def clean_name(self):
    #     value= self.cleaned_data.get('name')
    #     totalWords = value.split(' ') 
    #     if len(totalWords)>3:
    #         self.add_error('name','You can maximum used 3 words ')
    #     else:
    #         value

class ContactFormTwo(forms.ModelForm):
    class Meta:
        model=Contact
        fields='__all__'

class PostForm(forms.ModelForm):
    class Meta:
        model=Post
        exclude=['user','id',' slug','created_at'] 
        widgets={
           'subject':forms.CheckboxSelectMultiple(attrs={
               'multiple':True,
           }),
            'class_in':forms.CheckboxSelectMultiple(attrs={
               'multiple':True,
           })
        } 
       
   